package player

import "fmt"

var id = 0

type Player struct {
	userId           int
	name             string
	position         int
	noofTurnsBlocked int
}

type Players []*Player

func NewPlayer(nm string, pos int) *Player {
	id += 1
	return &Player{userId: id, name: nm, position: pos, noofTurnsBlocked: 0}
}

func (p *Player) GetId() int {
	return p.userId
}

func (p *Player) GetName() string {
	return p.name
}

func (p *Player) GetCurrentPosition() int {
	return p.position
}

func (p *Player) GetBlockedTurns() int {
	return p.noofTurnsBlocked
}

func (p *Player) SetBlockTurns(turns int) {
	p.noofTurnsBlocked = turns
}

func (p *Player) Move(pos int) {
	p.position = pos
}

func (players Players) CheckPositionOverlap(idx int) {
	for i := 0; i < len(players); i++ {
		if i == idx {
			continue
		}
		if players[i].position == players[idx].position {
			fmt.Println(players[i].name, "moved from", players[i].position, "to 1 as", players[idx].name, "occupied this position")
			players[i].Move(1)
		}
	}
}
